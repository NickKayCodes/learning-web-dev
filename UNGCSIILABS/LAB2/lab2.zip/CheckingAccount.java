public class CheckingAccount extends BankAccount {
    private double fee = 0.15;

    public CheckingAccount(String name, double amount, double fee) {
        super(name, amount);
        super.setAccountNumber(getAccountNumber() + "-10");
        this.fee = fee;
    }

    public boolean withdraw(double amount) {
        return super.withdraw(amount + fee);
    }

}